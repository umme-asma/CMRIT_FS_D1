<?php
    $databaseHost = 'localhost';
    $databaseName = 'vaccination'; 
    $databaseUsername = 'root';  
    $databasePassword = '';  

    $conn = mysqli_connect($databaseHost, $databaseUsername, $databasePassword, $databaseName,"3306");
?>